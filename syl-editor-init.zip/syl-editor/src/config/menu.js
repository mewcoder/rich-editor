let menu = {
    //查看源码
    source: {
        className: 'syl-menu-source',
        icon: 'fa fa-code',
        action: 'viewSource',
        showStatus: true
    },
    //字体名称
    fontName: {
        className: 'syl-menu-fontName',
        icon: 'fa fa-font',
        dropList: true
    },
    //字号大小
    fontSize: {
        className: 'syl-menu-fontSize',
        icon: 'fa fa-header',
        dropList: true
    },
    //文字加粗
    bold: {
        className: 'syl-menu-bold',
        icon: 'fa fa-bold',
        action: 'bold',
        showStatus: true
    },
    //下划线
    underLine: {
        className: 'syl-menu-underline',
        icon: 'fa fa-underline',
        action: 'underline',
        showStatus: true
    },
    //删除线
    strikeThrough: {
        className: 'syl-menu-strike',
        icon: 'fa fa-strikethrough',
        action: 'strikeThrough',
        showStatus: true
    },
    //颜色
    color: {
        className: 'syl-menu-color',
        icon: 'fa fa-paint-brush',
        dropList: true
    },
    //文字左对齐
    justifyLeft: {
        className: 'syl-menu-align-left',
        icon: 'fa fa-align-left',
        action: 'justifyLeft',
    },
    //文字居中对齐
    justifyCenter: {
        className: 'syl-menu-align-center',
        icon: 'fa fa-align-center',
        action: 'justifyCenter',
    },
    //文字右对齐
    justifyRight: {
        className: 'syl-menu-align-center',
        icon: 'fa fa-align-right',
        action: 'justifyRight',
    },
    //插入有序列表
    insertOrderedList: {
        className: 'syl-menu-ol',
        icon: 'fa fa-list-ol',
        action: 'insertOrderedList'
    },
    //插入无序列表
    insertUnorderedList: {
        className: 'syl-menu-ul',
        icon: 'fa fa-list-ul',
        action: 'insertUnorderedList'
    },
    //添加超链接
    link: {
        className: 'syl-menu-link',
        icon: 'fa fa-link',
        dropList: true
    },
    //取消超链接
    unlink: {
        className: 'syl-menu-unlink',
        icon: 'fa fa-unlink',
        action: 'unlink'
    },
    //插入图片
    picture: {
        className: 'syl-menu-picture',
        icon: 'fa fa-picture-o',
        dropList: true
    },
    //插入表格
    table: {
        className: 'syl-menu-table',
        icon: 'fa fa-table',
        dropList: true
    },
    //取消格式
    removeFormat: {
        className: 'syl-menu-remove-format',
        icon: 'fa fa-eraser',
        action: 'removeFormat'
    },
    //重做
    redo: {
        className: 'syl-menu-redo',
        icon: 'fa fa-repeat',
        action: 'redo'
    },
    //撤销
    undo: {
        className: 'syl-menu-undo',
        icon: 'fa fa-undo',
        action: 'undo'
    }
}
//导出配置
export default {
    getMenu() {
        return menu;
    }
}