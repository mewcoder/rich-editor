<template>
  <div class="hello syl-editor editor-layout">
    <syl-menubar></syl-menubar>
    <syl-editarea></syl-editarea>
    <div class="drop-list">
        <div v-for="item in list" :key="item">
          <component :is="'syl-' + item"></component>
        </div>
    </div>
<SourceCode></SourceCode>
  </div>
</template>
<script>
import Menubar from './menu/menubar'
import Editarea from './content/editarea'
import FontName from './menu/fontName'
import FontSize from './menu/fontSize'
import Color from './menu/color'
import Picture from './menu/picture'
import Table from './menu/table'
import Link from './menu/link'
import SourceCode from './menu/source'

export default {
  name: 'layout',
  data () {
    return {
     list: ['fontname', 'fontsize', 'color', 'picture','table', 'link']		//下拉框组件列表
    }
  },
  components: {
	//存放组件
    'syl-menubar': Menubar,
    'syl-editarea': Editarea,
    'syl-fontSize': FontSize,
    'syl-fontName':FontName,
    'syl-color': Color,
    'syl-picture': Picture,
    'syl-table': Table,
    'syl-link': Link,
    SourceCode
  }
}
</script>
<style lang="scss">
h1, h2 {
  font-weight: normal;
}

li {
  margin: 0;
}

a {
  color: #42b983;
  cursor: pointer;
}

table {
    width: 100%;
    margin: 5px 0 10px 0;
    tr {
        td {
            min-width: 50px;
            padding: 5px;
            border-left: 1px solid #ddd;
            border-top: 1px solid #ddd;
            &:last-child {
                border-right: 1px solid #ddd;
            }
        }
        &:last-child {
            td {
                border-bottom: 1px solid #ddd;
            }
        }
    }
}

img {
    max-width: 100%;
    max-height: auto;
}

.syl-editor {
    max-width: 1000px;
    margin: 0 auto;
}

.drop-list-item {
  max-width: 200px;
  position: absolute;
  border: 1px solid #eee;
  background: #fff;
  li {
    border-bottom: 1px solid #eee;
    a {
        display: inline-block;
        text-decoration: none;
        color: #666;
    }
    &:last-child {
      border: none;
    }
  }
  &:before {
    content: ' '
  }
}
</style>