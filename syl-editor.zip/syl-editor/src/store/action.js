export default {
    //展示下拉框
    showDropList({ commit }, data) {
        commit('SHOW_DROP_LIST', data)
    },
    //更新编辑区内容
    updateContent({ commit }, data) {
        commit('UPDATE_CONTENT', data)
    },
    //更新选择的值
    updateSelectValue({ commit }, data) {
        commit('UPDATE_SELECTED_VALUE', data)
    },
    //更新菜单状态
    updateMenuStatus({ commit }, data) {
        commit('UPDATE_MENU_STATUS', data)
    },
    //执行命令
    execCommand({ commit }, data) {
        commit('EXEC_COMMAND', data)
    },
    //获取节点位置
    getNodePosition({ commit }, data) {
        commit('NODE_POSITION', data)
    },
    //切换视图
    changeView({ commit }, data) {
        commit('CHANGE_VIEW', data)
    }
}