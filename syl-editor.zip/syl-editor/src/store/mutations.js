// 导入事件类型
import {
    // 下拉框事件类型
    SHOW_DROP_LIST,
    // 更新编辑区内容事件类型
    UPDATE_CONTENT,
    // 更新选择的值事件类型
    UPDATE_SELECTED_VALUE,
    // 更新菜单状态事件类型
    UPDATE_MENU_STATUS,
    // 执行命令事件类型
    EXEC_COMMAND,
    //获取节点位置事件类型
    NODE_POSITION,
    // 切换视图事件类型
    CHANGE_VIEW
} from './mutations-types'

//定义处理各个事件类型的回调函数
export default {

    [SHOW_DROP_LIST]({ menuBar }, data) {
        // 下拉框事件类型对回调函数
        for (let menu in menuBar) {
            if (menuBar[menu].showDropList !== undefined) {
                if (data && data.name === menu) {
                    menuBar[menu].showDropList = data.display
                } else {
                    menuBar[menu].showDropList = false
                }
            }
        }
    },[UPDATE_CONTENT](state, data) {
        // 更新编辑区内容事件类型
        state.content = data
    },
    [UPDATE_MENU_STATUS]({ menuBar }, data) {
        // 更新菜单状态事件类型
        if ('all' in data) {
            for (let menu in menuBar) {
                menuBar[menu].status = data.all
            }
            return
        }
        for (let name in data) {
            if (menuBar[name].showStatus) {
                menuBar[name].status = data[name]
            } else {
                menuBar[name].status = 'default'
            }
        }
    },
    [UPDATE_SELECTED_VALUE]({ menuBar }, data) {
        // 更新选择的值事件类型
        menuBar[data.name].value = data.value
    },
    [EXEC_COMMAND](state, data) {
        // 执行命令事件类型
        state.command = data
    },
    [CHANGE_VIEW](state, data) {
        // 切换视图事件类型
        state.sourceView = data
    },
    [NODE_POSITION](state, data) {
        //获取节点位置事件类型
        state.position = {
            top: data.top,
            right: data.right,
            bottom: data.bottom + document.body.scrollTop,
            left: data.left
        }
    }
}