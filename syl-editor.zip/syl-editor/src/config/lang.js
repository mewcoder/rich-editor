export default {
    source: {
        title: '源码'
        //可继续添加其他语言 title: 'sourceCode'，下同
    },
    fontName: {
        title: '字体'
    },
    fontSize: {
        title: '字号'
    },
    bold: {
        title: '加粗'
    },
    underLine: {
        title: '下划线'
    },
    strikeThrough: {
        title: '删除线'
    },
    color: {
        title: '颜色'
    },
    justifyLeft: {
        title: '左对齐'
    },
    justifyCenter: {
        title: '居中'
    },
    justifyRight: {
        title: '右对齐'
    },
    insertOrderedList: {
        title: '有序列表'
    },
    insertUnorderedList: {
        title: '无序列表'
    },
    link: {
        title: '链接'
    },
    unlink: {
        title: '取消链接'
    },
    picture: {
        title: '图片'
    },
    table: {
        title: '表格'
    },
    removeFormat: {
        title: '清除格式'
    },
    redo: {
        title: '重做'
    },
    undo: {
        title: '撤销'
    }
}